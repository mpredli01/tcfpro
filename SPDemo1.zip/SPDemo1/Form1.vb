﻿Imports Microsoft.SharePoint
Imports Microsoft.Office.Server
Imports Microsoft.SharePoint.Administration

Public Class frmMain

    Private Sub btnExit_Click(sender As System.Object, e As System.EventArgs) Handles btnExit.Click
        End
    End Sub

    ' Get the Farm Object
    Private Sub btnFarm_Click(sender As System.Object, e As System.EventArgs) Handles btnFarm.Click
        Dim Farm As SPFarm
        Dim Services As SPServiceCollection
        Dim Service As SPService
        Dim TempStr As String
        Farm = SPFarm.Local
        TempStr = "Farm: " & Farm.Name & " - " & Farm.DisplayName & vbCrLf
        Services = Farm.Services
        TempStr &= "Services: " & vbCrLf
        For Each Service In Services
            TempStr &= "   " & Service.Name & " - " & Service.DisplayName & vbCrLf
        Next
        MsgBox(TempStr, MsgBoxStyle.OkOnly, "Services")
    End Sub

    'Get the list of Web Applications
    Private Sub btnGetWebApps_Click(sender As System.Object, e As System.EventArgs) Handles btnGetWebApps.Click
        Dim WebApplication As SPWebApplication
        Dim WebApplicationCollection As SPWebApplicationCollection
        lstWebApplications.Items.Clear()
        WebApplicationCollection = SPWebService.ContentService.WebApplications
        For Each WebApplication In WebApplicationCollection
            lstWebApplications.Items.Add(WebApplication.Name)
        Next
    End Sub

    ' Get the list of Site Collections from the selected Web Application
    Private Sub lstWebApplications_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles lstWebApplications.SelectedIndexChanged
        Dim WebApplication As SPWebApplication
        Dim SiteCollection As SPSite
        lstSiteCollections.Items.Clear()
        WebApplication = SPWebService.ContentService.WebApplications(lstWebApplications.Text)
        For Each SiteCollection In WebApplication.Sites
            lstSiteCollections.Items.Add(SiteCollection.Url)
        Next
    End Sub

    ' Get the list of sites within a site collection
    Private Sub lstSiteCollections_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles lstSiteCollections.SelectedIndexChanged
        Dim SiteCollection As SPSite
        Dim RootWebSite As SPWeb
        Dim SubSite As SPWeb
        lstSites.Items.Clear()
        SiteCollection = New SPSite(lstSiteCollections.Text)
        RootWebSite = SiteCollection.OpenWeb()
        lstSites.Items.Add(RootWebSite.Url)
        For Each SubSite In RootWebSite.Webs
            lstSites.Items.Add(SubSite.Url)
        Next
    End Sub

    ' Start recursing through sites
    Private Sub btnRecurse_Click(sender As System.Object, e As System.EventArgs) Handles btnRecurse.Click
        Dim SiteCollection As SPSite
        Dim RootWebSite As SPWeb
        lstSites.Items.Clear()
        If lstSiteCollections.Text = "" Then
            MsgBox("Select a Site Collection before recursing", MsgBoxStyle.OkOnly, "Error!")
            Exit Sub
        End If
        SiteCollection = New SPSite(lstSiteCollections.Text)
        RootWebSite = SiteCollection.OpenWeb()
        lstSites.Items.Add(RootWebSite.Url)
        RecurseSites(RootWebSite.Webs)
    End Sub

    ' Recurse through sites
    Private Sub RecurseSites(SiteList As SPWebCollection)
        Dim CurrentSite As SPWeb
        For Each CurrentSite In SiteList
            Application.DoEvents()
            lstSites.Items.Add(CurrentSite.Url)
            If CurrentSite.Webs.Count > 0 Then
                RecurseSites(CurrentSite.Webs)
            End If
        Next
    End Sub

    Private Sub lstSites_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles lstSites.SelectedIndexChanged
        Dim List As SPList
        Dim SiteCollection As SPSite
        Dim Site As SPWeb
        Dim tString As String
        lstLists.Items.Clear()
        SiteCollection = New SPSite(lstSites.Text)
        Site = SiteCollection.OpenWeb()
        For Each List In Site.Lists
            tString = List.Title
            If chkShowItemCount.CheckState = 1 Then
                tString &= " (" & List.ItemCount & ")"
            End If
            If chkShowCreated.CheckState = 1 Then
                tString &= " Created: " & List.Created.ToString & " by " & List.Author.Name
            End If
            lstLists.Items.Add(tString)
        Next
    End Sub

    Private Sub lstLists_SelectedIndexChanged(sender As System.Object, e As System.EventArgs) Handles lstLists.SelectedIndexChanged
        Dim List As SPList
        Dim SiteCollection As SPSite
        Dim Site As SPWeb
        Dim Item As SPListItem
        lstItems.Items.Clear()
        SiteCollection = New SPSite(lstSites.Text)
        Site = SiteCollection.OpenWeb()
        List = Site.Lists.Item(lstLists.Text)
        For Each Item In List.Items
            lstItems.Items.Add(Item.Name & " - " & Item.DisplayName)
        Next
    End Sub
End Class
