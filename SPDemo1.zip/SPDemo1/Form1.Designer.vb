﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmMain
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.btnExit = New System.Windows.Forms.Button()
        Me.btnFarm = New System.Windows.Forms.Button()
        Me.lstWebApplications = New System.Windows.Forms.ListBox()
        Me.btnGetWebApps = New System.Windows.Forms.Button()
        Me.lstSiteCollections = New System.Windows.Forms.ListBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.lstSites = New System.Windows.Forms.ListBox()
        Me.btnRecurse = New System.Windows.Forms.Button()
        Me.lstLists = New System.Windows.Forms.ListBox()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.lstItems = New System.Windows.Forms.ListBox()
        Me.chkShowItemCount = New System.Windows.Forms.CheckBox()
        Me.chkShowCreated = New System.Windows.Forms.CheckBox()
        Me.SuspendLayout()
        '
        'btnExit
        '
        Me.btnExit.Location = New System.Drawing.Point(12, 414)
        Me.btnExit.Name = "btnExit"
        Me.btnExit.Size = New System.Drawing.Size(75, 23)
        Me.btnExit.TabIndex = 1
        Me.btnExit.Text = "E&xit"
        Me.btnExit.UseVisualStyleBackColor = True
        '
        'btnFarm
        '
        Me.btnFarm.Location = New System.Drawing.Point(13, 34)
        Me.btnFarm.Name = "btnFarm"
        Me.btnFarm.Size = New System.Drawing.Size(123, 23)
        Me.btnFarm.TabIndex = 2
        Me.btnFarm.Text = "Get Farm Object"
        Me.btnFarm.UseVisualStyleBackColor = True
        '
        'lstWebApplications
        '
        Me.lstWebApplications.FormattingEnabled = True
        Me.lstWebApplications.HorizontalScrollbar = True
        Me.lstWebApplications.Location = New System.Drawing.Point(152, 34)
        Me.lstWebApplications.Name = "lstWebApplications"
        Me.lstWebApplications.Size = New System.Drawing.Size(359, 108)
        Me.lstWebApplications.TabIndex = 3
        '
        'btnGetWebApps
        '
        Me.btnGetWebApps.Location = New System.Drawing.Point(13, 63)
        Me.btnGetWebApps.Name = "btnGetWebApps"
        Me.btnGetWebApps.Size = New System.Drawing.Size(123, 23)
        Me.btnGetWebApps.TabIndex = 4
        Me.btnGetWebApps.Text = "Get Web Applications"
        Me.btnGetWebApps.UseVisualStyleBackColor = True
        '
        'lstSiteCollections
        '
        Me.lstSiteCollections.FormattingEnabled = True
        Me.lstSiteCollections.HorizontalScrollbar = True
        Me.lstSiteCollections.Location = New System.Drawing.Point(152, 182)
        Me.lstSiteCollections.Name = "lstSiteCollections"
        Me.lstSiteCollections.Size = New System.Drawing.Size(359, 108)
        Me.lstSiteCollections.TabIndex = 5
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Location = New System.Drawing.Point(149, 18)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(93, 13)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Web Applications:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(149, 166)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(82, 13)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Site Collections:"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(152, 312)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(33, 13)
        Me.Label3.TabIndex = 8
        Me.Label3.Text = "Sites:"
        '
        'lstSites
        '
        Me.lstSites.FormattingEnabled = True
        Me.lstSites.HorizontalScrollbar = True
        Me.lstSites.Location = New System.Drawing.Point(152, 329)
        Me.lstSites.Name = "lstSites"
        Me.lstSites.Size = New System.Drawing.Size(359, 108)
        Me.lstSites.TabIndex = 9
        '
        'btnRecurse
        '
        Me.btnRecurse.Location = New System.Drawing.Point(13, 93)
        Me.btnRecurse.Name = "btnRecurse"
        Me.btnRecurse.Size = New System.Drawing.Size(123, 23)
        Me.btnRecurse.TabIndex = 10
        Me.btnRecurse.Text = "Recurse Sites"
        Me.btnRecurse.UseVisualStyleBackColor = True
        '
        'lstLists
        '
        Me.lstLists.FormattingEnabled = True
        Me.lstLists.HorizontalScrollbar = True
        Me.lstLists.Location = New System.Drawing.Point(532, 182)
        Me.lstLists.Name = "lstLists"
        Me.lstLists.Size = New System.Drawing.Size(359, 108)
        Me.lstLists.TabIndex = 11
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(529, 166)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(31, 13)
        Me.Label4.TabIndex = 12
        Me.Label4.Text = "Lists:"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(529, 312)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(35, 13)
        Me.Label5.TabIndex = 13
        Me.Label5.Text = "Items:"
        '
        'lstItems
        '
        Me.lstItems.FormattingEnabled = True
        Me.lstItems.HorizontalScrollbar = True
        Me.lstItems.Location = New System.Drawing.Point(532, 329)
        Me.lstItems.Name = "lstItems"
        Me.lstItems.Size = New System.Drawing.Size(359, 108)
        Me.lstItems.TabIndex = 14
        '
        'chkShowItemCount
        '
        Me.chkShowItemCount.AutoSize = True
        Me.chkShowItemCount.Location = New System.Drawing.Point(532, 99)
        Me.chkShowItemCount.Name = "chkShowItemCount"
        Me.chkShowItemCount.Size = New System.Drawing.Size(107, 17)
        Me.chkShowItemCount.TabIndex = 15
        Me.chkShowItemCount.Text = "Show Item Count"
        Me.chkShowItemCount.UseVisualStyleBackColor = True
        '
        'chkShowCreated
        '
        Me.chkShowCreated.AutoSize = True
        Me.chkShowCreated.Location = New System.Drawing.Point(532, 125)
        Me.chkShowCreated.Name = "chkShowCreated"
        Me.chkShowCreated.Size = New System.Drawing.Size(114, 17)
        Me.chkShowCreated.TabIndex = 16
        Me.chkShowCreated.Text = "Show Created Info"
        Me.chkShowCreated.UseVisualStyleBackColor = True
        '
        'frmMain
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(903, 454)
        Me.Controls.Add(Me.chkShowCreated)
        Me.Controls.Add(Me.chkShowItemCount)
        Me.Controls.Add(Me.lstItems)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.lstLists)
        Me.Controls.Add(Me.btnRecurse)
        Me.Controls.Add(Me.lstSites)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lstSiteCollections)
        Me.Controls.Add(Me.btnGetWebApps)
        Me.Controls.Add(Me.lstWebApplications)
        Me.Controls.Add(Me.btnFarm)
        Me.Controls.Add(Me.btnExit)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Name = "frmMain"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "SPDemo1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnExit As System.Windows.Forms.Button
    Friend WithEvents btnFarm As System.Windows.Forms.Button
    Friend WithEvents lstWebApplications As System.Windows.Forms.ListBox
    Friend WithEvents btnGetWebApps As System.Windows.Forms.Button
    Friend WithEvents lstSiteCollections As System.Windows.Forms.ListBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lstSites As System.Windows.Forms.ListBox
    Friend WithEvents btnRecurse As System.Windows.Forms.Button
    Friend WithEvents lstLists As System.Windows.Forms.ListBox
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents lstItems As System.Windows.Forms.ListBox
    Friend WithEvents chkShowItemCount As System.Windows.Forms.CheckBox
    Friend WithEvents chkShowCreated As System.Windows.Forms.CheckBox

End Class
